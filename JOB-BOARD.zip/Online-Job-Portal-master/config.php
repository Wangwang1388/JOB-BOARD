<?php

$host = "localhost";
$user  = "root";
$password =  "sreelal";
$database1 = "jobportal";
$database2 = "location";
$db1 = new mysqli($host, $user, $password, $database1);

$db2 = new mysqli($host, $user, $password, $database2);

*/
?>