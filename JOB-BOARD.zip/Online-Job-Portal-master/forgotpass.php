<?php
session_start();
include_once('config.php');
if (isset($_POST['email'])){
    $email = $_POST['email'];
    $query="select * from login where email='$email'";
    $result   = mysqli_query($db1,$query);
    $count=mysqli_num_rows($result);
    
    $sentmail=0;
    if($count==1)
    {
        $rows=mysqli_fetch_array($result);
        $pass  =  $rows['password'];//FETCHING PASS
        
        $to = $rows['email'];
        
        $from = "Job Portal";
        $url = "http://www.jobportal.com/";
        $body  =  "Your Password Recovery
		-----------------------------------------------
		Url : $url;
		email Details is : $to;
		Here is your password  : $pass;
		Sincerely,
		Coding Cyber";
        $from = "help@jobportal.com";
        $subject = "JobPortal Password recovered";
        $headers1 = "From: $from\n";
        $headers1 .= "Content-type: text/html;charset=iso-8859-1\r\n";
        $headers1 .= "X-Priority: 1\r\n";
        $headers1 .= "X-MSMail-Priority: High\r\n";
        $headers1 .= "X-Mailer: Just My Server\r\n";
        $sentmail = mail ( $to, $subject, $body, $headers1 );
    } else {
        if ($_POST ['email'] != "") {
            echo '<span style="color: #ff0000;"> Not found your email in our database</span>';
		}
    }
    if($sentmail==1)
    {
        echo "<span style='color: #ff0000;'> Your Password Has Been Sent To Your Email Address.</span>";
    }
    else
    {
        if($_POST['email']!="")
            echo "<span style='color: #ff0000;'> Cannot send password to your e-mail address.Problem with sending mail...</span>";
    }
}
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Forgot Password</title>
</head>
<body>
<form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
    <label> Enter your User ID : </label>
    <input id="username" type="text" name="email" />
    <input id="button" type="submit" name="button" value="Sent My Password" />
</form>
</body>
</html>